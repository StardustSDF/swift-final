//
//  kiollian_swift_finalApp.swift
//  kiollian swift final
//
//  Created by O'Toole, Killian - Student on 12/16/24.
//

import SwiftUI

@main
struct kiollian_swift_finalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
