//
//  ContentView.swift
//  kiollian swift final
//
//  Created by O'Toole, Killian - Student on 12/16/24.
//

import SwiftUI

struct ContentView: View {
    @State private var waveY: CGFloat = UIScreen.main.bounds.height
    @State private var waveRotation: Angle = .degrees(0)
    @State private var waveVelocityY: CGFloat = 10
    @State private var isHolding = false
    @State private var obstacles: [RotatedObstacle] = []
    @State private var score = 0
    @State private var highScore = 0
    @State private var gameOver = false
    @State private var trailPoints: [CGPoint] = []
    @State private var isPaused = false
    
    
    private let baseForwardSpeed: CGFloat = 10
    private let maxForwardSpeed: CGFloat = 10
    private var forwardSpeed: CGFloat { min(maxForwardSpeed, baseForwardSpeed + CGFloat(score) / 200) }
    private let obstacleSpacing: CGFloat = 45 // 45 pro 69 noob
    private let waveSize: CGSize = CGSize(width: 20, height: 5)
    
    @StateObject private var gameCoordinator = GameCoordinator()
    
    var body: some View {
        ZStack {
            Color.black
                .ignoresSafeArea()
            
            Path { path in
                guard !trailPoints.isEmpty else { return }
                path.move(to: trailPoints.first!)
                for point in trailPoints {
                    path.addLine(to: point)
                }
            }
            .stroke(Color.cyan.opacity(0.7), lineWidth: 3)
            
            ForEach(obstacles) { obstacle in
                Rectangle()
                    .fill(Color.green)
                    .frame(width: obstacle.size.width, height: obstacle.size.height)
                    .rotationEffect(obstacle.rotation)
                    .position(x: obstacle.position.x, y: obstacle.position.y)
            }
            
            Rectangle()
                .fill(Color.cyan)
                .frame(width: waveSize.width, height: waveSize.height)
                .rotationEffect(waveRotation)
                .position(x: UIScreen.main.bounds.width / 4, y: waveY)
            
            VStack {
                Text("'My Swift Final'")
                    .foregroundColor(.white)
                Text("by Killian")
                    .foregroundColor(.white)
                Text("Score: \(score)")
                    .foregroundColor(.white)
                    .font(.largeTitle)
                
                Text("High Score: \(highScore)")
                    .foregroundColor(.white)
                    .font(.headline)
            }
            .position(x: UIScreen.main.bounds.width / 2, y: 50)
            
            VStack {
                Spacer()
                HStack {
                    Spacer()
                    Button(action: togglePause) {
                        Text(isPaused ? "Resume" : "Pause")
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.gray.opacity(0.7))
                            .cornerRadius(10)
                    }
                    .padding()
                }
            }
        }
        .gesture(
            DragGesture(minimumDistance: 0)
                .onChanged { _ in if !isPaused { isHolding = true } }
                .onEnded { _ in isHolding = false }
        )
        .onAppear {
            startGame()
        }
        .onDisappear {
            gameCoordinator.stopGameLoop()
        }
        .onChange(of: isPaused) { paused in
            if paused {
                gameCoordinator.stopGameLoop()
            } else {
                gameCoordinator.startGameLoop { deltaTime in
                    updateGame(deltaTime: deltaTime)
                }
            }
        }
    }
    
    // MARK: - Game Logic
    
    private func startGame() {
        waveY = UIScreen.main.bounds.height / 2
        waveRotation = .degrees(0)
        waveVelocityY = 5
        isHolding = false
        gameOver = false
        score = 0
        obstacles = []
        trailPoints = []
        
        for i in 0..<1 {
            let xPosition = UIScreen.main.bounds.width + CGFloat(i) * obstacleSpacing
            addObstacle(at: xPosition) // 1100 pro 1300 noob
        }
        
        gameCoordinator.startGameLoop { deltaTime in
            updateGame(deltaTime: deltaTime)
        }
    }
    
    private func togglePause() {
        isPaused.toggle()
    }
    
    private func addObstacle(at xPosition: CGFloat) {
        let screenHeight = UIScreen.main.bounds.height
        let randomY = CGFloat.random(in: 100...(screenHeight - 100))
        let randomSize = CGFloat.random(in: 40...(screenHeight / 4))
        let size = CGSize(width: randomSize, height: randomSize)
        let rotation = Angle.degrees(45)
        
        let obstacle = RotatedObstacle(
            position: CGPoint(x: xPosition, y: randomY),
            size: size,
            rotation: rotation
        )
        
        obstacles.append(obstacle)
    }
    
    private func updateGame(deltaTime: TimeInterval) {
        guard !gameOver else { return }
        
        waveVelocityY = isHolding ? max(-maxForwardSpeed, -10 - CGFloat(score) / 200) : min(maxForwardSpeed, 10 + CGFloat(score) / 200)
        waveRotation = isHolding ? .degrees(-45) : .degrees(45)
        waveY += waveVelocityY * CGFloat(deltaTime * 60)
        
        if waveY < -50 || waveY > UIScreen.main.bounds.height + 50 {
            gameOver = true
            gameCoordinator.stopGameLoop()
            resetGame()
            return
        }
        
        // Move obstacles
        for index in obstacles.indices {
            obstacles[index].position.x -= forwardSpeed * CGFloat(deltaTime * 60)
        }
        
        obstacles.removeAll { $0.position.x < -50 }
        
        if let lastObstacle = obstacles.last, lastObstacle.position.x < UIScreen.main.bounds.width - obstacleSpacing {
            addObstacle(at: UIScreen.main.bounds.width + obstacleSpacing)
        }
        
        updateTrail()
        checkCollisions()
        score += Int(deltaTime * 60)
    }
    
    private func resetGame() {
        highScore = max(highScore, score)
        startGame()
    }
    
    private func updateTrail() {
        let radians = CGFloat(waveRotation.radians)
        let waveHalfWidth = waveSize.width / 2
        
        let backPoint = CGPoint(
            x: UIScreen.main.bounds.width / 4 - waveHalfWidth * cos(radians),
            y: waveY - waveHalfWidth * sin(radians)
        )
        
        trailPoints.append(backPoint)
        
        for index in trailPoints.indices {
            trailPoints[index].x -= forwardSpeed
        }
        
        trailPoints.removeAll { $0.x < 0 }
    }
    
    private func checkCollisions() {
        let waveBox = RotatedRectangle(
            center: CGPoint(x: UIScreen.main.bounds.width / 4, y: waveY),
            size: waveSize,
            rotation: waveRotation
        )
        
        for obstacle in obstacles {
            let obstacleBox = RotatedRectangle(
                center: obstacle.position,
                size: obstacle.size,
                rotation: obstacle.rotation
            )
            
            if waveBox.intersects(obstacleBox) {
                gameOver = true
                gameCoordinator.stopGameLoop()
                resetGame()
            }
        }
    }
}

// MARK: - Game Coordinator
final class GameCoordinator: ObservableObject {
    private var displayLink: CADisplayLink?
    private var gameLoop: ((_ deltaTime: TimeInterval) -> Void)?
    private var lastTimestamp: TimeInterval?
    
    func startGameLoop(_ gameLoop: @escaping (_ deltaTime: TimeInterval) -> Void) {
        stopGameLoop()
        self.gameLoop = gameLoop
        lastTimestamp = nil
        displayLink = CADisplayLink(target: self, selector: #selector(step))
        displayLink?.add(to: .main, forMode: .default)
    }
    
    func stopGameLoop() {
        displayLink?.invalidate()
        displayLink = nil
        gameLoop = nil
        lastTimestamp = nil
    }
    
    @objc private func step(displayLink: CADisplayLink) {
        guard let gameLoop = gameLoop else { return }
        if lastTimestamp == nil {
            lastTimestamp = displayLink.timestamp
        }
        let deltaTime = displayLink.timestamp - (lastTimestamp ?? displayLink.timestamp)
        lastTimestamp = displayLink.timestamp
        gameLoop(deltaTime)
    }
}

// MARK: - Model structs
struct RotatedObstacle: Identifiable {
    let id = UUID()
    var position: CGPoint
    var size: CGSize
    var rotation: Angle
}

struct RotatedRectangle {
    let center: CGPoint
    let size: CGSize
    let rotation: Angle
    
    var corners: [CGPoint] {
        let halfWidth = size.width / 2
        let halfHeight = size.height / 2
        let radians = CGFloat(rotation.radians)
        
        let unrotatedCorners = [
            CGPoint(x: -halfWidth, y: -halfHeight),
            CGPoint(x: halfWidth, y: -halfHeight),
            CGPoint(x: halfWidth, y: halfHeight),
            CGPoint(x: -halfWidth, y: halfHeight)
        ]
        
        return unrotatedCorners.map { corner in
            let rotatedX = corner.x * cos(radians) - corner.y * sin(radians)
            let rotatedY = corner.x * sin(radians) + corner.y * cos(radians)
            return CGPoint(x: rotatedX + center.x, y: rotatedY + center.y)
        }
    }
    
    func intersects(_ other: RotatedRectangle) -> Bool {
        for corner in corners {
            if pointInPolygon(corner, polygon: other.corners) {
                return true
            }
        }
        for corner in other.corners {
            if pointInPolygon(corner, polygon: corners) {
                return true
            }
        }
        return false
    }
    
    private func pointInPolygon(_ point: CGPoint, polygon: [CGPoint]) -> Bool {
        var intersects = false
        for i in 0..<polygon.count {
            let v1 = polygon[i]
            let v2 = polygon[(i + 1) % polygon.count]
            if ((v1.y > point.y) != (v2.y > point.y)) &&
                (point.x < (v2.x - v1.x) * (point.y - v1.y) / (v2.y - v1.y) + v1.x) {
                intersects.toggle()
            }
        }
        return intersects
    }
}

#Preview {
    ContentView()
}
